#ifndef UNTITLED_OPERATIONTAG_H
#define UNTITLED_OPERATIONTAG_H
#include "DataPacket.h"

class READERDLL_API OperationTag
{
private:
	int32_t tagCount;
	string strPc;
	string strCrc;
	string strEpc;
	string strData;
	int32_t dataLen;
	int32_t antId;
	int32_t readCount;
public:
	explicit OperationTag(DataPacket& packet);

	~OperationTag();

	int32_t getTagCount();

	string getStrPc();

	string getStrCrc();

	string getStrEpc();

	string getStrData();

	int32_t getDataLen();

	int32_t getAntId();

	int32_t getReadCount();
};

#endif