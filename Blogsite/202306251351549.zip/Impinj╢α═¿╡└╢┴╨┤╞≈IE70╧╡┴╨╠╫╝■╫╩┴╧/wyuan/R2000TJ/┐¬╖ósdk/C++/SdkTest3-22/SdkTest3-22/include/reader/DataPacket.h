//
// Created by naz on 11/5/20.
//

#ifndef UNTITLED_DATAPACKET_H
#define UNTITLED_DATAPACKET_H

#include <cstring>
#include <exception>
#include "../utils/Tools.h"
#include "reader_enum.h"
#include "../transport/Status.h"

class READERDLL_API DataPacket {
private:
    //Raw byte array
    uint8_t *g_packet{};
    //Raw byte array length
    size_t g_packetLength = 0;
public:
    /**
     * Data to send
     *
     * @param address Reader address
     * @param cmd Command code
     */
    DataPacket(uint8_t address, uint8_t cmd);

    /**
     *
     * Data to send
     *
     * @param address Reader address
     * @param cmd Command code
     * @param data Core data
     * @param length Core data length
     */
    DataPacket(uint8_t address, uint8_t cmd, const uint8_t *data, size_t dataLength);

    /**
     * Source data
     *
     * @param data Byte data
     * @param length Byte data length
     */
    DataPacket(uint8_t *data, size_t dataLength);

    /**
     * Destructor
     */
    ~DataPacket();

    /**
     * Get reader address, Used when the RS-485 interface is connected in series. The general address is from 0 to 254 (0xFE) and 255 (0xFF) is the public address.
     * The reader receives commands for its own address and public address
     *
     * @return The third byte of the packet
     */
    uint8_t GetAddress();

    /**
     * Get command code
     *
     * @return The fourth byte of the packet
     */
    uint8_t GetCmd();

    /**
     * Get checksum, checksum of all bytes except the checksum itself
     *
     * @return The last byte of the packet
     */
    uint8_t GetCheckSum();

    /**
     * Get the length of the core data in the packet (Packet length - (head + len + address + cmd + checksum)), Need to check if the length is 0
     *
     * @return Core data length
     */
    size_t GetCoreDataLength() const;

    /**
     * Get the starting index of the core data in the data packet (the fifth byte, the index is 4)
     *
     * @return starting index
     */
    const size_t g_coreDataStartIndex = 4;

    /**
     * Get raw data
     *
     * @return byte[]
     */
    uint8_t *GetPacket();

    /**
     * Get the length of the complete data
     * @return Raw data length
     */
    size_t GetPacketLength() const;

    void ToString();
};


#endif //UNTITLED_DATAPACKET_H
