//
// Created by naz on 11/4/20.
//

#ifndef UNTITLED_READER_H
#define UNTITLED_READER_H

#include <thread>
#include <list>
#include "Process.h"
#include "InventoryConfig.h"
#include "GpioInfo.h"
#include "FreqRegion.h"
#include "MaskInfo.h"
#include "OperationTag.h"

class READERDLL_API Reader {
private:
	Process* g_process;
	uint8_t* g_buffer;
	size_t g_length;
	bool g_isInventory;
	InventoryConfig* gInventoryConfig;

	static void RunPth(void*);

public:
	Reader();

	~Reader();

	/**
	 * Connect the reader
	 * @param handle Connection handle
	 * @return Whether the connection is successful
	 */
	bool Connect(ConnectHandle* handle);

	/**
	 * Disconnect
	 * @return Whether succeed
	 */
	bool Disconnect();

	/**
	 * Send and receive data
	 * @param The Data to send
	 * @return The received data, may be null
	 */
	DataPacket* SendAndReceivePacket(DataPacket& send);

	/**
	 * Reset the specified address reader.
	 * Operation successful: no data returned, reader restarted, buzzer sounded
	 * @return Whether the operation was successful
	 */
	bool Reset();

	/**
	 * Set the Serial Communication Baud rate.
	 * @param baudRate Serial port baud rate
	 * @return Whether the operation was successful
	 */
	bool SetBaudRate(uint8_t baudRate);

	/**
	 * Set Reader Address.
	 * @param address New Reader Address,value range0-254(0x00-0xFE)
	 *                  (0xFF Public Address)
	 * @return Whether the operation was successful
	 */
	bool SetReaderAddress(uint8_t address);

	/**
	 * Get Reader Firmware Version.
	 * @return Version number, The query fails and returns an empty string
	 */
	string GetFirmwareVersion();

	/**
	 * Set Buzzer behavior. <br>
	 * Buzzer behavior 0x02(Beep after every tag has identified) occupies CPU
	 * process time that affects anti-collision algorithm significantly. It is
	 * recommended that this option should be used for tag test.
	 * @param beeperMode Buzzer sound mode
	 * @return Whether the operation was successful
	 */
	bool SetBeeperMode(uint8_t beeperMode);

	/**
	 * Query internal temperature.
	 * @return Temperature, If the query fails, return 0
	 */
	int32_t GetReaderTemperature();

	GpioInfo ReadGpio();

	bool WriteGpio(uint8_t gpioType, uint8_t gpioValue);

	bool SetAntConnectionDetector(uint8_t detectorSensitivity);

	int32_t GetAntConnectionDetector();

	bool SetWorkAntenna(int32_t antennaId);

	int32_t GetWorkAntenna();

	bool SetOutputPower(uint8_t* outputPower, uint32_t outputPowerLength);

	void GetOutputPower(uint8_t* outputPower, uint32_t* outputPowerLength);

	bool SetOutputPowerUniformly(uint8_t uniformPower, bool isTemporary);

	bool SetFrequencyRegion(uint8_t region, uint8_t startRegion, uint8_t endRegion);

	bool SetUserDefineFrequency(uint32_t freqStart, uint32_t freqInterval, uint8_t freqQuantity);

	//FreqRegion GetFrequencyRegion();

	//bool SetReaderIdentifier(uint8_t* identifier, uint32_t identifierLength);

	//string GetReaderIdentifier();

	//bool SetRfLinkProfile(uint8_t profileId);

	//int32_t GetRfLinkProfile();

	//int32_t GetRfPortReturnLoss(uint8_t frequency);

	/**
	 * Set inventory configuration
	 * @param config Inventory configuration
	 */
	void SetInventoryConfig(InventoryConfig* config);

	/**
	 * Start inventory
	 * @return Status
	 */
	UHF_Status StartInventory();

	/**
	 * Stop inventory
	 */
	void StopInventory();

	list<OperationTag> readTag(uint8_t memBank, uint8_t wordAdd, uint8_t wordCnt,
		uint8_t* passwords, uint32_t passwordLen);

	list<OperationTag> readTag(uint8_t resAdd, uint8_t resCnt,
		uint8_t tidAdd, uint8_t tidCnt,
		uint8_t userAdd, uint8_t userCnt,
		uint8_t* passwords, uint32_t passwordLen,
		uint8_t session, uint8_t target,
		uint8_t readMode, uint8_t timeout);

	list<OperationTag> writeTag(uint8_t* passwords, uint32_t passwordLen,
		uint8_t memBank, uint8_t wordAdd, uint8_t wordCnt,
		bool blockWrite, uint8_t* data);

	list<OperationTag> lockTag(uint8_t* passwords, uint32_t passwordLen,
		uint8_t memBank, uint8_t lockType);

	list<OperationTag> killTag(uint8_t* passwords, uint32_t passwordLen);

	//void setImpinjFastTid(uint8_t fastTidType, bool save);

	//uint32_t getImpinjFastTid();

	//void setEpcMatch(uint8_t* epc, uint32_t epcLen);

	//string getEpcMatch();

	//bool clearEpcMatch();

	//void setTagMask(uint8_t function, uint8_t target, uint8_t action,
	//	uint8_t memBank, uint8_t maskAdd, uint32_t maskLen,
	//	uint8_t* mask, uint8_t truncate);

	//MaskInfo getTagMask();

	//void clearTagMask(uint8_t function);

	//void setReaderStatus(uint8_t status);

	//uint8_t getReaderStatus();
};


#endif //UNTITLED_READER_H
