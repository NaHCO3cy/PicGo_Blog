//
// Created by naz on 11/17/20.
//

#ifndef UNTITLED_TYPE_ENUM_H
#define UNTITLED_TYPE_ENUM_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

enum AntennaCount {
    // Single channel antenna port
    SINGLE_CHANNEL = 1,
    // Four-channel antenna port
    FOUR_CHANNELS = 4,
    // Eight channel antenna port
    EIGHT_CHANNELS = 8,
    // 16-channel antenna port
    SIXTEEN_CHANNELS = 16
};

enum BaudRate {
    // 38400 bps
    _38400 = 3,
    // 115200 bps
    _115200
};

enum Beeper {
    // be quiet
    QUIET = 0,
    // Sound after each inventory
    ONCE_END_BEEP,
    // Every time a tag is read, it sounds
    PER_TAG_BEEP
};

enum Freq {
    // 865.00 MHz
    _865000 = 0x00,
    // 865.50 MHz
    _865500 = 0x01,
    // 866.00 MHz
    _866000 = 0x02,
    // 866.50 MHz
    _866500 = 0x03,
    // 867.00 MHz
    _867000 = 0x04,
    // 867.50 MHz
    _867500 = 0x05,
    // 868.00 MHz
    _868000 = 0x06,
    // 902.00 MHz
    _902000 = 0x07,
    // 902.50 MHz
    _902500 = 0x08,
    // 903.00 MHz
    _903000 = 0x09,
    // 903.50 MHz
    _903500 = 0x0A,
    // 904.00 MHz
    _904000 = 0x0B,
    // 904.50 MHz
    _904500 = 0x0C,
    // 905.00 MHz
    _905000 = 0x0D,
    // 905.50 MHz
    _905500 = 0x0E,
    // 906.00 MHz
    _906000 = 0x0F,
    // 906.50 MHz
    _906500 = 0x10,
    // 907.00 MHz
    _907000 = 0x11,
    // 907.50 MHz
    _907500 = 0x12,
    // 908.00 MHz
    _908000 = 0x13,
    // 908.50 MHz
    _908500 = 0x14,
    // 909.00 MHz
    _909000 = 0x15,
    // 909.50 MHz
    _909500 = 0x16,
    // 910.00 MHz
    _910000 = 0x17,
    // 910.50 MHz
    _910500 = 0x18,
    // 911.00 MHz
    _911000 = 0x19,
    // 911.50 MHz
    _911500 = 0x1A,
    // 912.00 MHz
    _912000 = 0x1B,
    // 912.50 MHz
    _912500 = 0x1C,
    // 913.00 MHz
    _913000 = 0x1D,
    // 913.50 MHz
    _913500 = 0x1E,
    // 914.00 MHz
    _914000 = 0x1F,
    // 914.50 MHz
    _914500 = 0x20,
    // 915.00 MHz
    _915000 = 0x21,
    // 915.50 MHz
    _915500 = 0x22,
    // 916.00 MHz
    _916000 = 0x23,
    // 916.50 MHz
    _916500 = 0x24,
    // 917.00 MHz
    _917000 = 0x25,
    // 917.50 MHz
    _917500 = 0x26,
    // 918.00 MHz
    _918000 = 0x27,
    // 918.50 MHz
    _918500 = 0x28,
    // 919.00 MHz
    _919000 = 0x29,
    // 919.50 MHz
    _919500 = 0x2A,
    // 920.00 MHz
    _920000 = 0x2B,
    // 920.50 MHz
    _920500 = 0x2C,
    // 921.00 MHz
    _921000 = 0x2D,
    // 921.50 MHz
    _921500 = 0x2E,
    // 922.00 MHz
    _922000 = 0x2F,
    // 922.50 MHz
    _922500 = 0x30,
    // 923.00 MHz
    _923000 = 0x31,
    // 923.50 MHz
    _923500 = 0x32,
    // 924.00 MHz
    _924000 = 0x33,
    // 924.50 MHz
    _924500 = 0x34,
    // 925.00 MHz
    _925000 = 0x35,
    // 925.50 MHz
    _925500 = 0x36,
    // 926.00 MHz
    _926000 = 0x37,
    // 926.50 MHz
    _926500 = 0x38,
    // 927.00 MHz
    _927000 = 0x39,
    // 927.50 MHz
    _927500 = 0x3A,
    // 928.00 MHz
    _928000 = 0x3B
};

enum ClearMaskId {
    // tag mask all
    CLEAR_TAG_MASK_ALL = 0,
    // tag mask No.1
    CLEAR_TAG_MASK_NO1,
    // tag mask No.2
    CLEAR_TAG_MASK_NO2,
    // tag mask No.3
    CLEAR_TAG_MASK_NO3,
    // tag mask No.4
    CLEAR_TAG_MASK_NO4,
    //tag mask No.5
    CLEAR_TAG_MASK_NO5
};

enum FastTidType {
    // Disable
    DISABLE = 0x00,
    // Focus tag
    FOCUS_TAG = 0x8C,
    // Fast tag
    FAST_TAG = 0x8D,
    // Johar tag
    JOHAR_TAG = 0x90
};

enum GpioInType {
    // GPIO port 3
    Gpio3 = 0x03,
    // GPIO port 4
    Gpio4 = 0x04
};

enum LockMemBank {
    // User Memory
    USER_MEMORY = 0x01,
    // TID Memory
    TID_MEMORY = 0x02,
    // EPC Memory
    EPC_MEMORY = 0x03,
    // Access Password
    ACCESS_PASSWORD = 0x04,
    // Kill Password
    KILL_PASSWORD = 0x05
};

enum LockType {
    // open
    OPEN = 0x00,
    // locking
    LOCK = 0x01,
    // Open permanently
    PERMANENT_OPEN = 0x02,
    // Permanently locked
    PERMANENT_LOCK = 0x03,
    // Permanently lock R6 tags
    PERMANENT_LOCK_R6 = 0x06
};

enum MaskAction {
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // | Assert SL or inventoried ->A        |         Deassert SL or inventoried ->B       |
    // --------------------------------------|-----------------------------------------------
    Action0 = 0x00,
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // | Assert SL or inventoried ->A        |                   Do nothing                 |
    // --------------------------------------|-----------------------------------------------
    Action1 = 0x01,
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // |            Do nothing               |         Deassert SL or inventoried->B        |
    // --------------------------------------|-----------------------------------------------
    Action2 = 0x02,
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // |      Negate SL or(A->B,B->A)        |                   Do nothing                 |
    // --------------------------------------|-----------------------------------------------
    Action3 = 0x03,
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // |   Deassert SL or inventoried ->B    |          Assert SL or inventoried->A         |
    // --------------------------------------|-----------------------------------------------
    Action4 = 0x04,
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // |   Deassert SL or inventoried ->B    |                   Do nothing                 |
    // --------------------------------------|-----------------------------------------------
    Action5 = 0x05,
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // |            Do nothing               |          Assert SL or inventoried->A         |
    // --------------------------------------|-----------------------------------------------
    Action6 = 0x06,
    // ---------Tag Matches Mask-------------|-----------Tag Doesn’t Match Mask--------------
    // |            Do nothing               |           Negate SL or (A->B, B->A)          |
    // --------------------------------------|-----------------------------------------------
    Action7 = 0x07
};

enum MaskId {
    // tag mask No.1
    TAG_MASK_NO1 = 0x01,
    // tag mask No.2
    TAG_MASK_NO2 = 0x02,
    // tag mask No.3
    TAG_MASK_NO3 = 0x03,
    // tag mask No.4
    TAG_MASK_NO4 = 0x04,
    // tag mask No.5
    TAG_MASK_NO5 = 0x05
};

enum MaskTarget {
    // Inventoried S0
    Inventoried_S0 = 0x00,
    // Inventoried S1
    Inventoried_S1 = 0x01,
    // Inventoried S2
    Inventoried_S2 = 0x02,
    // Inventoried S3
    Inventoried_S3 = 0x03,
    // SL
    SL = 0x04,
    // Johar tag
    JOHAR = 0x07
};

enum MemBank {
    // Reserved
    RESERVED = 0x00,
    // Epc
    EPC = 0x01,
    // Tid
    TID = 0x02,
    // User
    USER = 0x03
};

enum ProfileId {
    // Tari 25uS，FM0 40KHz
    Profile0 = 0xD0,
    // Tari 25uS，Miller 4 250KHz
    Profile1 = 0xD1,
    // Tari 25uS，Miller 4 300KHz
    Profile2 = 0xD2,
    // Tari 6.25uS，FM0 400KHz
    Profile3 = 0xD3
};

enum ReadMode {
    // Single label mode, no session control;
    // The fastest speed. Target and Session values will be ignored
    MODE1 = 0x00,
    // Single label mode with session control
    MODE2 = 0x01,
    // Multi-tab mode with session control
    MODE3 = 0x02
};

enum Region {
    // Radio Frequency Specification FCC
    FCC = 0x01,
    // Radio Frequency Specification ETSI
    ETSI = 0x02,
    // Radio Frequency Specification CHN
    CHN = 0x03
};

enum SelectFlag {
    // Select Flag 00
    SL0 = 0x00,
    // Select Flag 01
    SL1 = 0x01,
    // Select Flag 02
    SL2 = 0x02,
    // Select Flag 03
    SL3 = 0x03
};

enum Session {
    // Session 0
    S0 = 0x00,
    // Session 1
    S1 = 0x01,
    // Session 2
    S2 = 0x02,
    // Session 3
    S3 = 0x03
};

enum Target {
    // Inventoried Flag A
    A = 0x00,
    // Inventoried Flag B
    B = 0x01
};

//enum SwitchType {
//    // Close function
//    CLOSE = 0x00,
//    // Open function
//    OPEN = 0x01
//};
//
//enum SingleAntenna {
//    // No antenna
//    NONE = 0xFF,
//    // Antenna 1
//    ANT_A = 0x00
//};
//
//enum FourAntenna {
//    // No antenna
//    NONE = 0xFF,
//    // Antenna 1
//    ANT_A = 0x00,
//    // Antenna 2
//    ANT_B = 0x01,
//    // Antenna 3
//    ANT_C = 0x02,
//    // Antenna 4
//    ANT_D = 0x03
//};
//
//enum EightAntenna {
//    // No antenna, Setting to this value means not polling the current antenna
//    NONE = 0xFF,
//    // Antenna 1
//    ANT_A = 0x00,
//    // Antenna 2
//    ANT_B = 0x01,
//    // Antenna 3
//    ANT_C = 0x02,
//    // Antenna 4
//    ANT_D = 0x03,
//    // Antenna 5
//    ANT_E = 0x04,
//    // Antenna 6
//    ANT_F = 0x05,
//    // Antenna 7
//    ANT_G = 0x06,
//    // Antenna 8
//    ANT_H = 0x07
//};
//
//enum HighEightAntenna {
//    // No antenna, Setting to this value means not polling the current antenna
//    NONE = 0xFF,
//    // Antenna 1
//    ANT_I = 0x00,
//    // Antenna 2
//    ANT_J = 0x01,
//    // Antenna 3
//    ANT_K = 0x02,
//    // Antenna 4
//    ANT_L = 0x03,
//    // Antenna 5
//    ANT_M = 0x04,
//    // Antenna 6
//    ANT_N = 0x05,
//    // Antenna 7
//    ANT_O = 0x06,
//    // Antenna 8
//    ANT_P = 0x07
//};

#ifdef __cplusplus
}
#endif // __cplusplus

#endif //UNTITLED_TYPE_ENUM_H
