//
// Created by naz on 11/16/20.
//

#ifndef UNTITLED_INVENTORYCALLBACK_H
#define UNTITLED_INVENTORYCALLBACK_H

#include "InventoryTag.h"
#include "InventoryTagEnd.h"
#include "InventoryFailure.h"

class InventoryCallback {
public:
    virtual void OnInventoryTag(InventoryTag *tag) = 0;

    virtual void OnInventoryTagEnd(InventoryTagEnd *tagEnd) = 0;

    virtual void OnInventoryFailure(InventoryFailure *failure) = 0;
};

#endif //UNTITLED_INVENTORYCALLBACK_H
