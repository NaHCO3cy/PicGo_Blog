//
// Created by naz on 11/17/20.
//

#ifndef UNTITLED_GPIOINFO_H
#define UNTITLED_GPIOINFO_H
#include "DataPacket.h"

class READERDLL_API GpioInfo {
private:
    uint8_t *gpioArray;
    uint32_t gpioArrayLength;
public:
    explicit GpioInfo(DataPacket &packet);

    virtual ~GpioInfo();

    uint8_t *getGpioArray() const;

    uint32_t getGpioArrayLength() const;
};


#endif //UNTITLED_GPIOINFO_H
