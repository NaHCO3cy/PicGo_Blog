//
// Created by naz on 11/5/20.
//

#ifndef UNTITLED_TCPHANDLE_H
#define UNTITLED_TCPHANDLE_H

#include <WinSock2.h>
#include <WS2tcpip.h>
#include <string>
#include "ConnectHandle.h"
#pragma comment(lib,"ws2_32.lib")

class READERDLL_API TcpHandle : public ConnectHandle {
private:
	SOCKET gSockClient;
	SOCKADDR_IN gAddrSrv;
	bool isConnect = false;
public:
	TcpHandle(std::string ip, uint32_t port);

	bool Connect() override;

	bool IsConnected() override;

	UHF_Status SendBytes(size_t length, uint8_t* data, uint32_t timeoutMs) override;

	UHF_Status ReceiveBytes(size_t length, size_t* dataLength, uint8_t* data, uint32_t timeoutMs) override;

	bool Disconnect() override;
};

#endif //UNTITLED_TCPHANDLE_H