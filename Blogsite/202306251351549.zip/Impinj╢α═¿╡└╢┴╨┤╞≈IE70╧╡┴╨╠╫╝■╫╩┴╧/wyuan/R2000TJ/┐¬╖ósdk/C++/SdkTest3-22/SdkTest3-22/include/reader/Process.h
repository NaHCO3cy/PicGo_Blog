//
// Created by naz on 11/5/20.
//

#ifndef UNTITLED_PROCESS_H
#define UNTITLED_PROCESS_H

#include "../transport/ConnectHandle.h"
#include "DataPacket.h"

class Process {
private:
    const uint32_t TIMEOUT_MS = 2000;
    ConnectHandle *g_handle = nullptr;
    uint8_t g_address;
public:
    Process();

    bool Connect(ConnectHandle *handle);

    UHF_Status SendPacket(DataPacket &send);

    UHF_Status ReceivePacket(uint8_t *data, size_t *dataLength);

    uint8_t GetAddress();

    bool Disconnect();
};


#endif //UNTITLED_PROCESS_H
