//
// Created by naz on 11/16/20.
//

#ifndef UNTITLED_INVENTORYCONFIG_H
#define UNTITLED_INVENTORYCONFIG_H

#include "DataPacket.h"
#include "InventoryCallback.h"

class READERDLL_API InventoryConfig {
private:
    uint8_t cmd;
    uint8_t *paramData;
    uint32_t paramDataLength;
    bool enablePhase;
    InventoryCallback *inventoryCallback;
public:
    InventoryConfig();

    virtual ~InventoryConfig();

    void RealTimeInventory(uint8_t repeat);

    void CustomSessionTargetInventory(uint8_t session, uint8_t target, uint8_t selectFlag,
                                      uint8_t phase, uint8_t powerSave, uint8_t repeat);

    void FastSwitchSingleAntennaInventory(uint8_t antennaA, uint8_t stayA, uint8_t antennaB, uint8_t stayB,
                                          uint8_t antennaC, uint8_t stayC, uint8_t antennaD, uint8_t stayD,
                                          uint8_t antennaE, uint8_t stayE, uint8_t antennaF, uint8_t stayF,
                                          uint8_t antennaG, uint8_t stayG, uint8_t antennaH, uint8_t stayH,
                                          uint8_t interval, uint8_t reserve1, uint8_t reserve2,
                                          uint8_t reserve3, uint8_t reserve4, uint8_t reserve5,
                                          uint8_t session, uint8_t target, uint8_t optimize, uint8_t ongoing,
                                          uint8_t targetQuantity, uint8_t phase, uint8_t repeat);

    uint8_t getCmd() const;

    uint8_t *getParamData() const;

    uint32_t getParamDataLength() const;

    bool isEnablePhase() const;

    void setInventoryCallback(InventoryCallback *callback);

    InventoryCallback *getInventoryCallback() const;
};

//class BaseInventory {
//public:
//    virtual uint8_t *getParamData() = 0;
//
//    virtual uint32_t getParamDataLength() = 0;
//
//    virtual bool isEnablePhase() = 0;
//
//public:
//};

//class CustomSessionTargetInventory {
//private:
//    uint8_t *param;
//    uint8_t session;
//    uint8_t target;
//    uint8_t selectFlag;
//    uint8_t phase;
//    uint8_t powerSave;
//    uint8_t repeat;
//public:
//    CustomSessionTargetInventory();
//
//    virtual ~CustomSessionTargetInventory();
//
//    uint8_t *getParamData();
//
//    static uint32_t getParamDataLength();
//
//    bool isEnablePhase();
//};


#endif //UNTITLED_INVENTORYCONFIG_H
