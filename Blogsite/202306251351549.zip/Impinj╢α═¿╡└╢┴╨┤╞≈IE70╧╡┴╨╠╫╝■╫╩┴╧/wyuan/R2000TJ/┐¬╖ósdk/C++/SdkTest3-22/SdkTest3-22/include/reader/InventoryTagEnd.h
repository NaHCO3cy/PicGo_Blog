//
// Created by naz on 11/14/20.
//

#ifndef UNTITLED_INVENTORYTAGEND_H
#define UNTITLED_INVENTORYTAGEND_H

#include "DataPacket.h"

class READERDLL_API InventoryTagEnd {
private:
    // working antenne
    int32_t currentAnt;
    // Reading speed of tag
    volatile int readRate;
    // accumulate Data returned
    int32_t totalRead;
    // Number of labels (the total number of labels that are not repeated after one inventory),
    // The tag Count defaults to -1, which means that the field data is invalid
    int32_t tagCount{};
public:
    InventoryTagEnd(DataPacket &packet);

    int32_t getCurrentAnt() const;

    volatile int32_t getReadRate() const;

    int32_t getTotalRead() const;

    int32_t getTagCount() const;
};


#endif //UNTITLED_INVENTORYTAGEND_H
