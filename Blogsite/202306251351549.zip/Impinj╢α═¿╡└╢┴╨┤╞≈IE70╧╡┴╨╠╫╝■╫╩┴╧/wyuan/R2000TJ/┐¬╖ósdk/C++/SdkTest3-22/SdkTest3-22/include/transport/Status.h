//
// Created by naz on 11/5/20.
//

#ifndef UNTITLED_STATUS_H
#define UNTITLED_STATUS_H
#include <cstdint>
#include <cstddef>
#include <cstdio>

#ifdef READERDLL_EXPORTS
#define READERDLL_API __declspec(dllexport)
#else
#define READERDLL_API __declspec(dllimport)
#endif

typedef uint32_t UHF_Status;

#define UHF_STATUS_MAKE(type, value) (((type) << 24) | (value))

#define UHF_SUCCESS_TYPE      0L
#define UHF_ERROR_TYPE_COMM   1L
#define UHF_ERROR_TYPE_CODE   2L

#define UHF_SUCCESS UHF_STATUS_MAKE(UHF_SUCCESS_TYPE, 0)

#define UHF_ERROR_COMM(x)           UHF_STATUS_MAKE(UHF_ERROR_TYPE_COMM, (x))
#define UHF_ERROR_COMM_ERRNO(x)     UHF_ERROR_COMM(0x8000 | (x))
#define UHF_ERROR_CODE(x)           UHF_STATUS_MAKE(UHF_ERROR_TYPE_CODE, (x))

#define UHF_ERROR_TIMEOUT           UHF_ERROR_COMM(1)
#define UHF_ERROR_UNCONNECTED       UHF_ERROR_COMM(2)
#define UHF_ERROR_PROCESS           UHF_ERROR_CODE(1)
#endif //UNTITLED_STATUS_H
