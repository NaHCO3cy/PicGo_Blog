#ifndef UNTITLED_MASKINFO_H
#define UNTITLED_MASKINFO_H

class MaskInfo
{
private:
public:
};

#endif