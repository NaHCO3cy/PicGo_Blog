//
// Created by naz on 11/16/20.
//

#ifndef UNTITLED_INVENTORYFAILURE_H
#define UNTITLED_INVENTORYFAILURE_H

#include "DataPacket.h"

class READERDLL_API InventoryFailure {
private:
    // Error code
    uint8_t errorCode;
    uint32_t antId{};
public:
    explicit InventoryFailure(DataPacket &packet);

    uint8_t getErrorCode() const;

    uint32_t getAntId() const;
};


#endif //UNTITLED_INVENTORYFAILURE_H
