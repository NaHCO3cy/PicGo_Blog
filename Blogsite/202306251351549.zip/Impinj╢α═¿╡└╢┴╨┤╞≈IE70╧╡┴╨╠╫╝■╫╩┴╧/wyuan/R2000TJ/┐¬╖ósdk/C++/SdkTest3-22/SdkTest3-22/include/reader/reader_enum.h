//
// Created by naz on 11/6/20.
//

#ifndef UNTITLED_READER_ENUM_H
#define UNTITLED_READER_ENUM_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

enum Head {
    // UHF mark to indicate the head of data package
    HEAD = 0xA0
};

enum Cmd {
    // Reset reader
    RESET = 0x70,
    // Set the serial communication baud rate
    SET_SERIAL_PORT_BAUD_RATE = 0x71,
    // Read reader firmware version
    GET_FIRMWARE_VERSION = 0x72,
    // Set the reader address
    SET_READER_ADDRESS = 0x73,
    // Set the reader antenna
    SET_WORK_ANTENNA = 0x74,
    // Query the current antenna working antenna
    GET_WORK_ANTENNA = 0x75,
    // Set the reader RF output power
    SET_OUTPUT_POWER = 0x76,
    // Query reader current output power
    GET_OUTPUT_POWER = 0x77,
    // Set the reader frequency range
    SET_FREQUENCY_REGION = 0x78,
    // Query reader working frequency range
    GET_FREQUENCY_REGION = 0x79,
    // Setting the buzzer state
    SET_BEEPER_MODE = 0x7A,
    // Query the working temperature of the current device
    GET_READER_TEMPERATURE = 0x7B,
    // Read GPIO level
    READ_GPIO_VALUE = 0x60,
    // Set GPIO level
    WRITE_GPIO_VALUE = 0x61,
    // Setting the antenna connection detector status
    SET_ANT_CONNECTION_DETECTOR = 0x62,
    // Read antenna connection detector status
    GET_ANT_CONNECTION_DETECTOR = 0x63,
    // Set the temporary RF output power of the reader
    SET_TEMPORARY_OUTPUT_POWER = 0x66,
    // Set Reader ID
    SET_READER_IDENTIFIER = 0x67,
    // Read reader ID
    GET_READER_IDENTIFIER = 0x68,
    // Set the communication rate of the RF link
    SET_RF_LINK_PROFILE = 0x69,
    // Read the communication rate of the RF link
    GET_RF_LINK_PROFILE = 0x6A,
    // Measure the return loss of the antenna port
    GET_RF_PORT_RETURN_LOSS = 0x7E,
    // Inventory tags
    INVENTORY = 0x80,
    // Read tag
    READ_TAG = 0x81,
    // Write tags
    WRITE_TAG = 0x82,
    // Lock tag
    LOCK_TAG = 0x83,
    // Inactivate tag
    KILL_TAG = 0x84,
    // Inventory tags (upload tag data in real time)
    REAL_TIME_INVENTORY = 0x89,
    // Quickly poll multiple antenna inventory tags
    FAST_SWITCH_ANT_INVENTORY = 0x8A,
    // Custom session and target inventory
    CUSTOMIZED_SESSION_TARGET_INVENTORY = 0x8B,
    // Set Monza tag to read TID quickly (settings are not saved to internal FLASH)
    SET_IMPINJ_FAST_TID = 0x8C,
    // Set Monza tag to read TID quickly (settings are saved to internal FLASH)
    SET_AND_SAVE_IMPINJ_FAST_TID = 0x8D,
    // Query the current fast TID setting
    GET_IMPINJ_FAST_TID = 0x8E,
    // Block write tag
    BLOCK_WRITE_TAG = 0x94,
    // Filter tag (cmd tag select) command
    OPERATE_TAG_MASK = 0x98,
    // Set the status of the reader (active reading, etc.)
    SET_READER_STATUS = 0xA0,
    // Query reader status
    QUERY_READER_STATUS = 0xA1,
};

enum ResultCode {
    // Command executed successfully
    SUCCESS = 0x10,
    // Command execution failed
    FAIL = 0x11,
    // CPU reset error
    MCU_RESET_ERROR = 0x20,
    // Turn on CW error
    CW_ON_ERROR = 0x21,
    // Antenna is not connected
    ANTENNA_MISSING_ERROR = 0x22,
    // Write flash error
    WRITE_FLASH_ERROR = 0x23,
    // Reading Flash ResultCode
    READ_FLASH_ERROR = 0x24,
    // Set transmit power error
    SET_OUTPUT_POWER_ERROR = 0x25,
    // Inventory label error
    TAG_INVENTORY_ERROR = 0x31,
    // Reading label error
    TAG_READ_ERROR = 0x32,
    // Write label error
    TAG_WRITE_ERROR = 0x33,
    // Lock tag error
    TAG_LOCK_ERROR = 0x34,
    // Kill tag error
    TAG_KILL_ERROR = 0x35,
    // No actionable label error
    NO_TAG_ERROR = 0x36,
    // Successful inventory but access failed
    INVENTORY_OK_BUT_ACCESS_FAIL = 0x37,
    // Cache is empty
    BUFFER_IS_EMPTY_ERROR = 0x38,
    // NXP chip custom instruction failed
    NXP_CUSTOM_COMMAND_FAIL = 0x3C,
    // Bad access tag or wrong access password
    ACCESS_OR_PASSWORD_ERROR = 0x40,
    // Invalid parameter
    PARAMETER_INVALID = 0x41,
    // word Cnt parameter exceeds specified length
    PARAMETER_INVALID_WORDCNT_TOO_LONG = 0x42,
    // Mem Bank parameters are out of range
    PARAMETER_INVALID_MEMBANK_OUT_OF_RANGE = 0x43,
    // Lock data area parameter is out of range
    PARAMETER_INVALID_LOCK_REGION_OUT_OF_RANGE = 0x44,
    // Lock Type parameter is out of range
    PARAMETER_INVALID_LOCK_ACTION_OUT_OF_RANGE = 0x45,
    // Reader address is invalid
    PARAMETER_READER_ADDRESS_INVALID = 0x46,
    // Antenna_id out of range
    PARAMETER_INVALID_ANTENNA_ID_OUT_OF_RANGE = 0x47,
    // Output power parameter is out of range
    PARAMETER_INVALID_OUTPUT_POWER_OUT_OF_RANGE = 0x48,
    // RF specification area parameter is out of range
    PARAMETER_INVALID_FREQUENCY_REGION_OUT_OF_RANGE = 0x49,
    // Baud rate parameter is out of range
    PARAMETER_INVALID_BAUDRATE_OUT_OF_RANGE = 0x4A,
    // Buzzer setting parameter is out of range
    PARAMETER_BEEPER_MODE_OUT_OF_RANGE = 0x4B,
    // EPC match length out of bounds
    PARAMETER_EPC_MATCH_LEN_TOO_LONG = 0x4C,
    // EPC match length error
    PARAMETER_EPC_MATCH_LEN_ERROR = 0x4D,
    // EPC matching parameters are out of range
    PARAMETER_INVALID_EPC_MATCH_MODE = 0x4E,
    // Frequency range setting parameter error
    PARAMETER_INVALID_FREQUENCY_RANGE = 0x4F,
    // Unable to receive tagged RN 16
    FAIL_TO_GET_RN16_FROM_TAG = 0x50,
    // DRM setting parameter error
    PARAMETER_INVALID_DRM_MODE = 0x51,
    // PLL cannot lock
    PLL_LOCK_FAIL = 0x52,
    // RF chip is not responding
    RF_CHIP_FAIL_TO_RESPONSE = 0x53,
    // The output does not reach the specified output power
    FAIL_TO_ACHIEVE_DESIRED_OUTPUT_POWER = 0x54,
    // Copyright certification failed
    COPYRIGHT_AUTHENTICATION_FAIL = 0x55,
    // Spectrum specification setting error
    SPECTRUM_REGULATION_ERROR = 0x56,
    // Output power is too low
    OUTPUT_POWER_TOO_LOW = 0x57,
    // Failed to measure return loss
    FAIL_TO_GET_RF_PORT_RETURN_LOSS = 0xEE,
    // unknown error
    UNKNOWN_ERROR = 0x58,
    // Send request queue is full, this request is invalid
    REQUEST_INVALID = 0xB0,
    // Send a request packet to the device,
    // and no response packet is received within the specified time
    REQUEST_TIMEOUT = 0xB1
};

#ifdef __cplusplus
}
#endif // __cplusplus
#endif //UNTITLED_READER_ENUM_H
