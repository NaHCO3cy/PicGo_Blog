//
// Created by naz on 11/4/20.
//

#ifndef UNTITLED_CONNECTHANDLE_H
#define UNTITLED_CONNECTHANDLE_H

#include "Status.h"

class READERDLL_API ConnectHandle {
private:

public:
    /**
     * Connect the device
     * @return bool
     */
    virtual bool Connect() = 0;

    /**
     * Is it connected
     * @return Is it connected
     */
    virtual bool IsConnected() = 0;

    /**
     * Send data to the device
     * @param length Length of data to be sent
     * @param data Data to send
     * @param timeoutMs Timeout for sending data, millisecond
     * @return Send result status code
     */
    virtual UHF_Status SendBytes(size_t length, uint8_t *data, uint32_t timeoutMs) = 0;

    /**
     * Receive data from device
     * @param length The length of the data to be received
     * @param dataLength Length of received data
     * @param data Data received
     * @param timeoutMs Timeout for receiving data, millisecond
     * @return Receive result status code
     */
    virtual UHF_Status ReceiveBytes(size_t length, size_t *dataLength, uint8_t *data, uint32_t timeoutMs) = 0;

    /**
     * Disconnect
     * @return bool
     */
    virtual bool Disconnect() = 0;
};


#endif //UNTITLED_CONNECTHANDLE_H
