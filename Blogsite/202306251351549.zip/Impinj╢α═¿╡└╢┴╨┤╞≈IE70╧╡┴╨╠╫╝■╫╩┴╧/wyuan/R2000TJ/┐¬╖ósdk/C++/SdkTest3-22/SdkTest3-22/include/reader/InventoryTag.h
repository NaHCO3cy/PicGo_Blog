//
// Created by naz on 11/14/20.
//

#ifndef UNTITLED_INVENTORYTAG_H
#define UNTITLED_INVENTORYTAG_H

#include "DataPacket.h"
#include <sstream>

using namespace std;

class READERDLL_API InventoryTag {
private:
    string pc;
    string epc;
    int32_t antId{};
    int32_t rssi{};
    int32_t phase{};
    string freq;
    bool isUserDefineRegion = false;
    int32_t userDefineFreqStart = 0;
    int32_t userDefineFreqInterval = -1;

    void SetFreqString(int freqQuantity);

public:
    explicit InventoryTag(DataPacket &packet);

    ~InventoryTag();

    int32_t getAntId() const;

    int32_t getRssi() const;

    int32_t getPhase() const;

    const string &getPc() const;

    const string &getEpc() const;

    const string &getFreq() const;
};


#endif //UNTITLED_INVENTORYTAG_H
