//
// Created by naz on 11/5/20.
//

#ifndef UNTITLED_TOOLS_H
#define UNTITLED_TOOLS_H

#include <cstdint>
#include <cstddef>
#include <string>
#include "../transport/Status.h"
using namespace std;

class READERDLL_API Tools {
private:
public:
    static uint8_t CalcCheckSum(const uint8_t *data, size_t length);

    static bool VerifyChecksum(const uint8_t *data, size_t length);

    static string BytesToHexString(const uint8_t *bytes, uint32_t byteLength);
};


#endif //UNTITLED_TOOLS_H
