//
// Created by naz on 11/5/20.
//

#ifndef UNTITLED_SERIALHANDLE_H
#define UNTITLED_SERIALHANDLE_H

#ifdef __linux
#include <termios.h>
#include <unistd.h>
#include <sys/ioctl.h>
#endif // __linux

#ifdef _WIN32
#include <Windows.h>
#include <string>
#endif // _WIN32


#include <fcntl.h>
#include <cerrno>
#include "ConnectHandle.h"

class READERDLL_API SerialHandle : public ConnectHandle {
private:
#ifdef __linux
	int g_fd{};
#endif // __linux
#ifdef _WIN32
	HANDLE hd;
#endif // _WIN32
	bool isConnect = false;
	std::string gDeviceName;
	uint32_t gPort;
public:
	SerialHandle(std::string deviceName, uint32_t port);

	bool Connect() override;

	bool IsConnected() override;

	UHF_Status SendBytes(size_t length, uint8_t* data, uint32_t timeoutMs) override;

	UHF_Status ReceiveBytes(size_t length, size_t* dataLength, uint8_t* data, uint32_t timeoutMs) override;

	bool Disconnect() override;
};

#endif //UNTITLED_SERIALHANDLE_H
