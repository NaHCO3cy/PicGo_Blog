#ifndef UNTITLED_FREQREGION_H
#define UNTITLED_FREQREGION_H

#include "DataPacket.h"

class READERDLL_API FreqRegion
{
private:
	int8_t region;
	int8_t freqStart;
	int8_t freqEnd;
	int8_t userDefineFreqStart;
	int8_t userDefineInterval;
	int8_t userDefineFreqQuantity;
public:
	//explicit FreqRegion(DataPacket& packet);

	//virtual ~FreqRegion();
};

#endif
